/// <reference types="node" />
/// <reference types="node" />
/// <reference types="node" />
/// <reference types="node" />
import { Http2SecureServer as HTTPSecureServer, Http2Server as HttpServer, Http2ServerRequest as HTTPServerRequest, Http2Stream as HTTPStream, SecureServerOptions } from 'http2';
import { Socket as PlainSocket } from 'net';
import { TLSSocket } from 'tls';
export interface APIConfiguration {
    key: string;
    url: string;
}
export type APIConfigurations = {
    base: APIConfiguration;
    [key: string]: Partial<APIConfiguration>;
};
export type Socket = PlainSocket | TLSSocket;
export type BufferedSocket = Socket & {
    buffers: Array<Buffer>;
};
export interface BufferedHTTPServerRequest extends HTTPServerRequest {
    socket: BufferedSocket;
}
export interface HeaderTransformation {
    source: string | RegExp;
    target: string | ((substring: string, ...parameters: Array<unknown>) => string);
}
export interface Configuration {
    publicKeyPath: string;
    privateKeyPath: string;
    nodeServerOptions: SecureServerOptions;
    host: string;
    port: number;
    forward: {
        headerTransformation: {
            retrieve: Array<HeaderTransformation>;
            send: Array<HeaderTransformation>;
        };
        host: string;
        port: number;
        tls: boolean;
    };
    humanChecker: {
        applicationInterfaces: APIConfigurations;
        identifiyAsHumanIfServiceThrowsException: boolean;
        skipSecrets: Array<string>;
    };
}
export type HTTPServer = HttpServer | HTTPSecureServer;
export interface Server {
    instance: HTTPServer;
    streams: Array<HTTPStream>;
    sockets: Array<Socket>;
    start: () => void;
    stop: () => void;
}
