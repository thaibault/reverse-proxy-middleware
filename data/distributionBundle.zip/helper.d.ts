import type { BufferedHTTPServerRequest, EvaluationParameters, EvaluationScopeStateAPIs, Forwarders, HTTPServerResponse, ResolvedHeaderTransformation, ResolvedForwarder, ResolvedForwarders } from './type';
import { Logger } from 'clientnode';
export declare const EVALUATION_SCOPE_NAMES: readonly ["array", "datetime", "filesystem", "functions", "indicators", "logger", "module", "number", "object", "string", "utility", "data", "error", "request", "response", "stateAPI", "stateAPIs"];
export declare const log: Logger;
export declare const applyStateAPIs: (request: BufferedHTTPServerRequest, response: HTTPServerResponse, forwarder: ResolvedForwarder) => Promise<{
    result: boolean;
    scope: EvaluationScopeStateAPIs;
}>;
export declare const determineForwarder: (request: BufferedHTTPServerRequest, response: HTTPServerResponse, forwarders: ResolvedForwarders) => null | ResolvedForwarder;
export declare const resolveForwarders: (forwarders: Forwarders) => ResolvedForwarders;
export declare const addParsedContentToRequest: (bufferedRequest: BufferedHTTPServerRequest) => void;
export declare const transformHeaders: (content: string, headerTransformations: Array<ResolvedHeaderTransformation>, parameters: EvaluationParameters) => string;
export declare const reverseProxyBufferedRequest: (request: BufferedHTTPServerRequest, response: HTTPServerResponse, forwarder: ResolvedForwarder, stateAPIScope: EvaluationScopeStateAPIs) => Promise<void>;
export default reverseProxyBufferedRequest;
