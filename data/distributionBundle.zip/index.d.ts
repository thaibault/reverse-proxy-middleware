import { Server } from './type';
declare const server: Server;
export default server;
